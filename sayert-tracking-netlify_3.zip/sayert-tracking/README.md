# SayertTracking

Combat-fitness training tracker for IDF pre-military prep - calendar, AI coach chat, training bank, attendance, and network management.

## Deploy to Netlify

1. Push this folder to a GitHub repo (or drag-and-drop the folder into Netlify's dashboard).
2. In Netlify: **Add new site → Import from Git**, pick the repo. Build settings are already set via `netlify.toml` (build command `npm run build`, publish directory `dist`).
3. In **Site settings → Environment variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_GEMINI_API_KEY`
   - `VITE_NETWORK_CODE`
4. Deploy. Without these set, the app still runs, just in local demo mode (browser storage instead of Supabase) so it's never a blank screen.

## Before your first real deploy

1. **Run `supabase-admin-security-fix.sql`** in your Supabase SQL editor. This is important: the original signup trigger trusted whatever role the client claimed, which is a real gap once real people can reach your site. This migration makes every signup a trainee, server-side, no exceptions.
2. Sign up once through the app with your own email.
3. In the Supabase SQL editor, run the one-line bootstrap command shown at the bottom of that same SQL file to make your account the first admin.
4. From then on, promote anyone else to admin or team leader directly from the app's Management tab - no codes involved.

## Local development

```
npm install
cp .env.example .env   # fill in your real values, this file is gitignored
npm run dev
```

## What's already wired up

- Team code verification runs server-side via the `verify_team_code` RPC (already built earlier) - the actual codes are never in this bundle.
- Network code (`VITE_NETWORK_CODE`) is required at signup and checked against the `verify_network_code` RPC once Supabase is connected.
- No admin invite code exists anywhere in this codebase anymore - see the SQL fix above for why and what replaced it.
- Local demo mode (no Supabase configured) uses the browser's own `localStorage`, not any Claude-specific API.
